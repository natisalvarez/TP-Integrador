#!/bin/bash

if [ "$1" = "-help" ]; then
   echo "Este script comprime un directorio y guarda el backup en otro directorio"
   echo ""
   echo "Cómo se usa:"
   echo  "Primero debés escribir este script para ejecutarlo, luego la carpeta ORIGEN, luego DESTINO"
   echo "Ejemplo: backup_full.sh /var/log /backup_dir"
   exit 0
fi

if [ $# -ne 2 ]; then
   echo "Error: debe indicar origen y destino."
   echo "Use: backup_full.sh -help"
   exit 1

fi

ORIGEN=$1
DESTINO=$2
FECHA=$(date +%Y%m%d)
NOMBRE=$(basename "$ORIGEN")
ARCHIVO="${NOMBRE}_bkp_${FECHA}.tar.gz"

if [ ! -d "$ORIGEN" ]; then
  echo "ERROR: el origen no existe o no es un directorio"
   exit 1
fi

if [ ! -d "$DESTINO" ]; then
   echo "ERROR: el destino no existe o no es un directorio"
   exit 1
fi

if ! findmnt "$DESTINO" > /dev/null; then
   echo "Error: el destino no esta montado"
   exit 1
fi

tar -czf "$DESTINO/$ARCHIVO" "$ORIGEN"

if [ $? -eq 0 ]; then
    echo "Back up creado correctamente: $DESTINO/$ARCHIVO"
else
    echo "ERROR al crear el backup"
    exit 1
fi


 
