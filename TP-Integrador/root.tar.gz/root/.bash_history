history
history -w
rm -f /root/.bash_history
journalctl --rotate
journalctl --vacuum-time=1s
apt clean
sync
poweroff
cat /etc/os'release

cat /etc/os-release
cp /etc/apt/sources.list /etc/apt/sources.bak
nano /etc/apt/sources.list
cp /etc/apt/sources.list /etc/apt/sources.list.bak
nano /etc/apt/spurces.list
nano /etc/apt/sources.list
cat /etc/apt/sources.list
vim /etc/apt/sources.list
:q!
clear
sed -i 's/bullseye/bookworm/g' /etc/apt/sources.list
sed -i 's/non-free/non-free non-free-firmware/g' /etc/apt/sources.list
cat /etc/apt/sources.list
apt update
cp /etc/apt/sources.list /etc/apt/sources.list/bak2
/etc/apt/sources.list /etc/apt/sources.list.bak2
cp /etc/apt/sources.list /etc/apt/sources.list.bak2
sed -i 's/cdn2-fastly.deb.debian.org/deb.debian.org/g' etc/apt/sources.list
shutdown now
nano /etc/apt/sources.list
vi /etc/apt/sources.list
vi /etc/apt/sources.list
vi /etc/apt/sources.list
vim /etc/apt/sources.list
clear
kill 506
rm 'f /etc/apt/.sources.list.swp
rm -f /etc/apt/.sources.list.swp
vim /etc/apt/sources.list
apt updates
apt update
vim /etc/apt/sources.list
apt update
apt upgrade --without-new-pkgs
<sadsdsaqqq
q
zsdas
qqqq
q
ee
asadasdasasdasasdasd
palermo
stty sane
dpkg --configure -a
apt upgrade --without-new-pkgs
a
s
s
stty sane
dpkg --configure-a
dpkg --configure -a
apt upgrade --without-new-pkgs
dpkg --configure -a
APT_LISTCHANGES_FRONTEND=none apt full-upgrade
dpkg --configure -a
apt autoremove --purge
apt clean
cat /etc/os-release
apt update
apt install openssh-server -y
/etc/ssh/sshd_config
vim /etc/ssh/sshd_config
systemctl restart ssh
ssh root@IP_de_la_maquina_virtual
hostname -I
shutdown now
exit
ip a
host -I
hostname 'I
hostname -I
ssh-keygen
hostname 'I
hostname -I
shh-copy-id root@192.168.1.125
ssh-copy-id root@192.168.1.125
vim /etc/ssh/sshd_config
systemctl restart ssh
ssh-copy-id root@192.168.1.125
ssh root@192.168.1.125
apt install apache2 php libapache2-mod-php -y
ls -la /root
find / -name "index.php" 2>/dev/null
tar -xzf /root/Material_Adicional_TPVMCA.tar.fz -c /root
tar -xzf /root/Material_Adicional_TPVMCA.tar.gz -c /root
tar -xzf /root/Material_Adicional_TPVMCA.tar.gz -C /root
ls -la /root
ls -la /root/Material_Adicional_TPVMCA
cp /root/Material_Adicional_TPVMCA/index.php
cp /root/Material_Adicional_TPVMCA/index.php /var/www/html/
cp /root/Material_Adicional_TPVMCA/logo.png /var/www/html/
systemctl restart apache2
curl http://localhost/index.php
ls -la /var/www/html
apt install mariadb-server -y
systemctl enable --now mariadb
systemctl status mariadb
mariadb < /root/Material_Adicional_TPVMCA/db.sql
curl http://localhost/index.php
php -v
cat /var/www/html/index.php
tail -n 30 /var/log/apache2.error.log
tail -n 30 /var/log/apache2/error.log
apt install php-mysqyl -y
apt install php-mysql -y
curl http://logalhost/index.php
http://localhost/index.php
curl http://localhost/index.php
systemctl restart apache2
curl http://localhost/index.php
clear
curl http://localhost/index.php
ip a
ip route
nano /etc/network/interfaces
apt update
apt install nano
nano /etc/network/interfaces
shutdown now
shutdown now
cat /etc/network/interfaces
systemctl status networking
ip a
nano /etc/interfaces/network
nano /etc/network/interfaces
ifup --force enp0s3
nano /etc/network/interfaces
shutdown now
