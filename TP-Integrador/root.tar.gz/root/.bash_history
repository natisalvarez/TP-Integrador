history
history -w
rm -f /root/.bash_history
journalctl --rotate
journalctl --vacuum-time=1s
apt clean
sync
poweroff
apt update
vim /etc/apt/soruces.list
vi /etc/apt/soruces.list



vi sources.list
clear
cd /etc/apt
ls
vi /etc/apt/soruces.list
clear
cat /etc/apt/soruces.list
clear
cat /etc/apt/soruces.list
clear
vi sources.list
apt update
vi sources.list
apt update
vi sources.list
apt update
clear
vi sources.list
shutdown now
apt-get install openssh-server
systemctl status ssh
vi /etc/ssh/sshd_config
vi /etc/ssh/sshd_config
systemctl restart ssh
systemctl status ssh
mkdir /root/.ssh
vi /etc/ssh/sshd_config
systemctl status ssh
systemctl restart ssh
systemctl status ssh
ssh key-gen
ssh-keygen
hostname -I
shutdown now
apt update
apt search apache2
apt show apache2
apt search apache2
clear
apt update
apt install apache2 php libapache2-mod-php -y
php -v
ls -la /root
tar /root/Material_Adicional_TPVMCA.tar.gz
tar-tzf /root/Material_Adicional_TPVMCA.tar.gz
tar-tzf /root/Material_Adicional_TPVMCA.tar.gz
tar -tzf /root/Material_Adicional_TPVMCA.tar.gz
clear
tar -tzf /root/Material_Adicional_TPVMCA.tar.gz
tar -xzf /root/Material_Adicional_TPVMCA.tar.gz
ls -ls /root
ls -la /root
ls -la /root/Material_Adicional_TPVMCA
ls -la /var/www/html
vi /etc/apache2/mods-enable/dir.conf
vi /etc/apache2/mods-enabled/dir.conf
cp /root/index.php /root/logo.png /var/www/html/
clear
ls -la /root
ls -la /root/Material_Adicional_TPVMCA
cp /root/Material_Adicional_TPVMCA/index.php /root/Material_Adicional_TPVMCA/logo.png /var/www/html/
ls -la /www/var/html/
ls -la /var/www/html
mv /var/www/html/index.html /var/www/html/index_back-up.html
curl http://localhost/index.php
systemctl status apache2
curl http://localhost
cat /var/www/html/index.php
vi /etc/apache2/sites-enabled/000-default.conf
cat /var/www/html/index.php
tail -n 20 /var/loga/apache2/error.loh
tail -n 20 /var/loga/apache2/error.log
tail -n 20 /var/log/apache2/error.log
apt install php-mysqli -y
curl http://localhost/index.php
apt install mariadb-server -y
system restart apache2
systemctl restart apache2
curl http://localhost/index.php
systemctl enable --now mariadb
curl http://localhost/index.php
tail -n 20 /var/log/apache2/error.log
mysql < /root/db.sql
mysql < /root/Material_Adicional_TPVMCA/db.sql
curl http://localhost/index.php
shutdown now
lsblk
fdisk /dev/sdc
lsdk
lsblk
mkfs -t ext4 /dev/sdc1
mkfs -t ext4 /dev/sdc2
mkdir /www_dir
mkdir /backup_dir
mount /dev/sdc1
mount /dev/sdc1 /www_dir
mount /dev/sdc2 /backup_dir
df -h
vi /etc/fstab
vi /etc/fstab
vi /etc/fstab
vi /etc/fstab
vi /etc/fstab
vi /etc/fstab
systemctl daemon-reload
lsblk
mount -a
vi /etc/fstab
systemctl daemon-reload
mount -a
ls -l /var/www/html
cp -a /var/www/html/index.php /www_dir/
cp -a /var/www/html/logo.png /www_dir/
ls -l/www_dir
ls -l /www_dir/
cp /etc/apache2/sites-available/000-default.conf /etc/apache2/sites-available/000-default.conf.bak
vi /etc/apache2/sites-available/000-default.conf
apatche2ctl configtest
apatche2ctl configtest
apache2ctl configtest
systemctl restart apache
systemctl restart apache
sustemctl restart apache2
systemctl restart apache2
curl http://localhost/index.php
df -h
ls -l /www_dir
clear
cat /proc/partitions > /opt/particion
cat /opt/particion
clear
mkdir -p /opt/scripts
touch opt/scripts/backup_full.sh
rm -r /opt/scripts
clear
mkdir /opt/scripts
touch /opt/scripts/backup_full.sh
vi /opt/scripts/backup_full.sh
vi /opt/scripts/backup_full.sh
vi /opt/scripts/backup_full.sh
vi /opt/scripts/backup_full.sh
vi /opt/scripts/backup_full.sh
chmod +x /opt/scripts/backup_full.sh
/opt/scripts/backup_full.sh -help
vi /opt/scripts/backup_full.sh
/opt/scripts/backup_full.sh -help
ls -l /opt/scripts/backup_full.sh
vi /opt/scripts/backup_full.sh
vi /root/.ssh/id_rsa
rm /root/.ssh/id_rsa
rm /root/.ssh/id_rsa.pub
clear
ls -la /root/.ssh
ls -la /root/Material_Adicional_TPVMCA
vi /root/.ssh/authorized_keys
clear
cp /root/clave_publica.pub /root/.ssh/authorized_keys
clear
ls -la /root/Material_Adicional_TPVMCA
cp /root/Material_Adicional_TPVMCA_clave_publica.pub /root/.ssh/authorized_keys
clear
ls -la /root/Material_Adicional_TPVMCA
cp /root/Material_Adicional_TPVMCA/clave_publica.pub /root/.ssh/authorized_keys
ls - la /root/.ssh
ls -la /root/.ssh
chmod 700 /root/.ssh
chmod 600 /root/.ssh/authorized_keys
shutdown now
vi /opt/scripts/backup_full.s
vi /opt/scripts/backup_full.sh
ls -la /opt/scripts/backup_full.sh
/opt/scripts/backup_full.sh -help
/opt/scripts/backup_full.sh /var/log /backup_dir
/opt/scripts/backup_full.sh /www_dir /backup_dir
vi /opt/scripts/backup_full.sh
vi /opt/scripts/backup_full.sh
bash -n /opt/scripts/backup_full.sh
/opt/scripts/backup_full.sh -help
vi /opt/scripts/backup_full.sh
/opt/scripts/backup_full.sh /var/log /backup_dir
ls -l /backup_dir
crontab -e
contrab -1
contrab -l
crontab -l
systemctl status cron
crontab -l
clear
cat /etc/os-release
shutdown now
apt update
shudown now
shutdown now
hostname -I.
ping -c 4 8.8.8.8
apt update
ip a
ip route
cat /etc/resolv.conf
ping -c 4 deb.debian.org
ip a
ip route
echo "nameserver 8.8.8.8 > /etc/resolv.conf
echo "nameserver 8.8.8.8" > /etc/resolv.conf
apt update
apt full-upgrade
reboot
